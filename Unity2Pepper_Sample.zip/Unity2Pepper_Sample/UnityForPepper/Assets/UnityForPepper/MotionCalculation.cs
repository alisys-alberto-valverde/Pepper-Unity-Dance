﻿using UnityEngine;

public static class MotionCalculation
{
    public static void CalculateAndUpdate(this RobotMotionData motionData, Animator animator)
    {
        var rootTransform = animator.transform;

        #region RShoulder/RElbowまでの4つを計算
        {
            var tRShoulder = animator.GetBoneTransform(HumanBodyBones.RightUpperArm);
            var tRElbow = animator.GetBoneTransform(HumanBodyBones.RightLowerArm);
            var tRHand = animator.GetBoneTransform(HumanBodyBones.RightHand);

            #region 前半: Shoulderの角度2つまで

            //root固定座標上で方向単位ベクトルを貰ってゴリ押し計算
            var rUpperArm = MyMatrix33.ProjectOnTransformCoordinate(
                (tRElbow.position - tRShoulder.position).normalized, 
                rootTransform
                );

            //単純に腋の開き具合を確認してるだけ
            float rsroll = -Mathf.Asin(rUpperArm.x);
            //腕の上げ下げを取得
            float rspitch = -Mathf.Asin(rUpperArm.y / Mathf.Cos(rsroll));

            //あんま無いかもしれないけど、ピッチ角が90度に近いと計算誤差で事故がたまに起きる
            if (float.IsNaN(rspitch))
            {
                rspitch = -0.5f * Mathf.PI * Mathf.Sign(rUpperArm.y);
            }

            //肘が体の後ろに行くような大きい動きのケース。上のAsinだけだと[-0.5pi, 0.5pi]までしか表現できないため必要
            if (rUpperArm.z < 0)
            {
                if (rspitch > 0) rspitch = Mathf.PI - rspitch;
                else rspitch = -Mathf.PI - rspitch;
            }

            //NOTE: 計算によってはココで符号調整が必要
            motionData.RShoulderRoll = rsroll;
            motionData.RShoulderPitch = rspitch;

            #endregion

            #region 後半: Elbowの2つを計算

            //肘曲げは上腕と下腕の方向軸(Unityちゃんの場合ローカルX軸)でズレ見れば十分
            motionData.RElbowRoll = Vector3.Angle(
                tRShoulder.right, tRElbow.right
                ) * Mathf.PI / 180.0f;

            //肘のヒネリ(人間の場合肩のヒネリに相当)は若干の工夫を要する
            var rLowerArm = MyMatrix33.ProjectOnTransformCoordinate(
                (tRHand.position - tRElbow.position).normalized, 
                rootTransform
                );

            //上腕の回転を逆変換することでRShoulder(Roll|Pitch)=0.0に直したときの下腕方向ベクトルを取って来る
            var m1 = MyMatrix33.Rotation(RotationType.X, -rspitch);
            var m2 = MyMatrix33.Rotation(RotationType.Y, -rsroll);
            var v2 = m1.Dot(m2).Dot(rLowerArm);

            motionData.RElbowYaw = Mathf.Asin(Mathf.Clamp(v2.y, -1.0f, 1.0f));

            #endregion
        }
        #endregion

        #region LShoulder/LElbowまでの4つを計算
        {
            //NOTE: Pepper側の都合で右腕と符号が変わる箇所がある事だけ注意

            var tLShoulder = animator.GetBoneTransform(HumanBodyBones.LeftUpperArm);
            var tLElbow = animator.GetBoneTransform(HumanBodyBones.LeftLowerArm);
            var tLHand = animator.GetBoneTransform(HumanBodyBones.LeftHand);

            #region 前半: Shoulderの角度2つまで

            var lUpperArm = MyMatrix33.ProjectOnTransformCoordinate(
                (tLElbow.position - tLShoulder.position).normalized,
                rootTransform
                );

            float lsroll = -Mathf.Asin(lUpperArm.x);
            float lspitch = -Mathf.Asin(lUpperArm.y / Mathf.Cos(lsroll));

            if (float.IsNaN(lspitch))
            {
                lspitch = -0.5f * Mathf.PI * Mathf.Sign(lUpperArm.y);
            }

            if (lUpperArm.z < 0)
            {
                if (lspitch > 0) lspitch = Mathf.PI - lspitch;
                else lspitch = -Mathf.PI - lspitch;
            }

            motionData.LShoulderRoll = lsroll;
            motionData.LShoulderPitch = lspitch;

            #endregion

            #region 後半: Elbowの2つを計算

            //var lLowerArmFromChest = MyMatrix33.ProjectOnTransformCoordinate(-tLElbow.right, tChest);
            var lLowerArm = MyMatrix33.ProjectOnTransformCoordinate(
                (tLHand.position -tLElbow.position).normalized, 
                rootTransform
                );

            motionData.LElbowRoll = -Vector3.Angle(
                tLShoulder.right, tLElbow.right
                ) * Mathf.PI / 180.0f;

            var m1 = MyMatrix33.Rotation(RotationType.X, -lspitch);
            var m2 = MyMatrix33.Rotation(RotationType.Y, -lsroll);
            var v2 = m1.Dot(m2).Dot(lLowerArm);

            motionData.LElbowYaw = -Mathf.Asin(Mathf.Clamp(v2.y, -1.0f, 1.0f));

            #endregion
        }
        #endregion

        #region Headを計算
        {
            //Unityちゃんの場合tHeadのY方向ベクトルが「頭の正面が向いてる方向」に対応するのでそのまま使う
            var tHead = animator.GetBoneTransform(HumanBodyBones.Head);
            var headFront = MyMatrix33.ProjectOnTransformCoordinate(tHead.up, rootTransform);
            //TODO: この方法だと90度以上の首ひねりが表現できない(Pepperの首は110度くらい曲がる)が、
            //      だいたいのケースでは問題にならないので修正しないでもいい
            motionData.HeadYaw = -Mathf.Asin(headFront.x);

            motionData.HeadPitch = -Mathf.Asin(headFront.y);
        }
        #endregion

        #region 位置と方向を計算
        {
            //NOTE: このサンプルでは移動に制限がかかってるので計算してもあまり大した意味はない

            var tChest = animator.GetBoneTransform(HumanBodyBones.Chest);

            //NOTE: Pepperにとっての座標表現は「X-Y = 正面-左手側」なことに注意
            motionData.PosX = animator.rootPosition.z;
            motionData.PosY = -animator.rootPosition.x;

            //NOTE: Pepperは[-PI, PI]の範囲で角度表現したいっぽいので合わせておく
            motionData.Orientation = tChest.eulerAngles.y * Mathf.PI / 180.0f;
            if (motionData.Orientation > Mathf.PI)
            {
                motionData.Orientation -= 2.0f * Mathf.PI;
            }
        }
        #endregion

        //以下の3か所はちょっと計算めんどいのでパス

        //RWrist/LWristを計算
        //HINT: Unityちゃんの場合Character1_(Left|Right)Handのオイラー回転X軸が
        //  手首のヒネリに対応するので値を適切に扱うと計算可能

        //Hipを計算
        //HINT: Hipのtransformを参照して計算可能

        //Hand(手の開閉)の計算
        //HINT: 適当な指について指の曲がり具合から計算可能

    }

}
