﻿using System;
using UnityEngine;


/// <summary>座標計算のヘルパーとして使う3x3行列</summary>
public struct MyMatrix33
{
    public float C11;
    public float C12;
    public float C13;

    public float C21;
    public float C22;
    public float C23;

    public float C31;
    public float C32;
    public float C33;

    public Vector3 Row1
    {
        get { return new Vector3 { x = C11, y = C12, z = C13 }; }
        set
        {
            C11 = value.x;
            C12 = value.y;
            C13 = value.z;
        }
    }
    public Vector3 Row2
    {
        get { return new Vector3 { x = C21, y = C22, z = C23 }; }
        set
        {
            C21 = value.x;
            C22 = value.y;
            C23 = value.z;
        }
    }
    public Vector3 Row3
    {
        get { return new Vector3 { x = C31, y = C32, z = C33 }; }
        set
        {
            C31 = value.x;
            C32 = value.y;
            C33 = value.z;
        }
    }

    public Vector3 Col1
    {
        get { return new Vector3 { x = C11, y = C21, z = C31 }; }
        set
        {
            C11 = value.x;
            C21 = value.y;
            C31 = value.z;
        }
    }
    public Vector3 Col2
    {
        get { return new Vector3 { x = C12, y = C22, z = C32 }; }
        set
        {
            C12 = value.x;
            C22 = value.y;
            C32 = value.z;
        }
    }
    public Vector3 Col3
    {
        get { return new Vector3 { x = C13, y = C23, z = C33 }; }
        set
        {
            C13 = value.x;
            C23 = value.y;
            C33 = value.z;
        }
    }

    public MyMatrix33 Dot(MyMatrix33 m2) { return Dot(this, m2); }
    public Vector3 Dot(Vector3 v) { return Dot(this, v); }

    /// <summary>行列積を求めます。</summary>
    public static MyMatrix33 Dot(MyMatrix33 m1, MyMatrix33 m2)
    {
        return new MyMatrix33()
        {
            C11 = Vector3.Dot(m1.Row1, m2.Col1),
            C12 = Vector3.Dot(m1.Row1, m2.Col2),
            C13 = Vector3.Dot(m1.Row1, m2.Col3),

            C21 = Vector3.Dot(m1.Row2, m2.Col1),
            C22 = Vector3.Dot(m1.Row2, m2.Col2),
            C23 = Vector3.Dot(m1.Row2, m2.Col3),

            C31 = Vector3.Dot(m1.Row3, m2.Col1),
            C32 = Vector3.Dot(m1.Row3, m2.Col2),
            C33 = Vector3.Dot(m1.Row3, m2.Col3),
        };
    }

    public static Vector3 Dot(MyMatrix33 m, Vector3 v)
    {
        return new Vector3()
        {
            x = Vector3.Dot(m.Row1, v),
            y = Vector3.Dot(m.Row2, v),
            z = Vector3.Dot(m.Row3, v)
        };
    }

    /// <summary>3次元空間の基底を張るベクトル上でターゲットのベクトルを成分表記し直したベクトルを取得します。</summary> 
    public static Vector3 ProjectOnCoordinate(Vector3 target, Vector3 right, Vector3 up, Vector3 forward)
    {
        return new Vector3()
        {
            x = Vector3.Dot(target, right),
            y = Vector3.Dot(target, up),
            z = Vector3.Dot(target, forward)
        };
    }

    public static Vector3 ProjectOnTransformCoordinate(Vector3 target, Transform baseTransform)
    {
        return ProjectOnCoordinate(target, baseTransform.right, baseTransform.up, baseTransform.forward);
    }

    /// <summary>回転軸と回転角を指定して回転行列を生成します。</summary>
    public static MyMatrix33 Rotation(RotationType rotationType, float angleRad)
    {
        switch (rotationType)
        {
            case RotationType.X:
                return RotationAroundX(angleRad);
            case RotationType.Y:
                return RotationAroundY(angleRad);
            case RotationType.Z:
                return RotationAroundZ(angleRad);
            default:
                throw new InvalidOperationException();
        }
    }

    private static MyMatrix33 RotationAroundX(float angleRad)
    {
        return new MyMatrix33()
        {
            C11 = 1.0f,
            //C12 = 0.0f,
            //C13 = 0.0f,
            //C21 = 0.0f,
            C22 = Mathf.Cos(angleRad),
            C23 = -Mathf.Sin(angleRad),
            //C31 = 0.0f,
            C32 = Mathf.Sin(angleRad),
            C33 = Mathf.Cos(angleRad)
        };
    }

    private static MyMatrix33 RotationAroundY(float angleRad)
    {
        return new MyMatrix33()
        {
            C11 = Mathf.Cos(angleRad),
            //C12 = 0.0f,
            C13 = Mathf.Sin(angleRad),
            //C21 = 0.0f,
            C22 = 1.0f,
            //C23 = 0.0f,
            C31 = -Mathf.Sin(angleRad),
            //C32 = 0.0f,
            C33 = Mathf.Cos(angleRad)
        };
    }

    private static MyMatrix33 RotationAroundZ(float angleRad)
    {
        return new MyMatrix33()
        {
            C11 = Mathf.Cos(angleRad),
            C12 = -Mathf.Sin(angleRad),
            //C13 = 0.0f,
            C21 = Mathf.Sin(angleRad),
            C22 = Mathf.Cos(angleRad),
            //C23 = 0.0f,
            //C31 = 0.0f,
            //C32 = 0.0f,
            C33 = 1.0f
        };
    }

}

public enum RotationType
{
    X,
    Y,
    Z
}

