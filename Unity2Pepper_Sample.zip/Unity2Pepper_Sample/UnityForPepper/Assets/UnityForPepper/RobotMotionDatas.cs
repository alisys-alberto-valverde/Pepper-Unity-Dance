﻿
public class RobotMotionData
{
    #region 間接名の列挙

    //ここからWheelBまではPepperのAPIであるALMotion::setAngles関数で動かせる関節の名前の一覧
    public float HeadYaw { get; set; }
    public float HeadPitch { get; set; }

    public float LShoulderPitch { get; set; }
    public float LShoulderRoll { get; set; }
    public float LElbowYaw { get; set; }
    public float LElbowRoll { get; set; }
    public float LWristYaw { get; set; }
    public float LHand { get; set; }

    public float HipRoll { get; set; }
    public float HipPitch { get; set; }
    public float KneePitch { get; set; }

    public float RShoulderPitch { get; set; }
    public float RShoulderRoll { get; set; }
    public float RElbowYaw { get; set; }
    public float RElbowRoll { get; set; }
    public float RWristYaw { get; set; }
    public float RHand { get; set; }

    public float WheelFL { get; set; }
    public float WheelFR { get; set; }
    public float WheelB { get; set; }

    //位置と方角はALMotion::moveTo関数などで動かすことが可能
    public float PosX { get; set; }
    public float PosY { get; set; }
    public float Orientation { get; set; }

    #endregion

    /// <summary>リモート指示で使うデータの一覧(順序はPepper側と事前に合意する必要あり)</summary>
    public float[] ArrayData
    {
        get
        {
            return new float[]
            {
                HeadYaw,
                HeadPitch,
                LShoulderPitch,
                LShoulderRoll,
                LElbowYaw,
                LElbowRoll,
                LWristYaw,
                RShoulderPitch,
                RShoulderRoll,
                RElbowYaw,
                RElbowRoll,
                RWristYaw,
                HipPitch,
                HipRoll,
                LHand,
                RHand,
                PosX,
                PosY,
                Orientation
            };
        }
    }
}

