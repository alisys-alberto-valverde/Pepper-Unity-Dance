﻿using UnityEngine;
using System.Collections;
using System.Net.Sockets;
using System;
using System.Linq;
using System.Net;

public class UdpSender : MonoBehaviour
{

    /// <summary>送信先(Pepper)のIPアドレス</summary>
    public string TargetIP = "127.0.0.1";

    /// <summary>送信先(Pepper)のポート番号</summary>
    public int TargetPort = 13000;

    /// <summary>スクリプトが更新とUDP送信処理を行うかどうかを決めるフラグ</summary>
    public bool Enabled = false;

    /// <summary>UDP送信を行う時間を設定。無制限に早い送信がしたい場合0.0にする</summary>
    public float UdpDeltaTime = 0.1f;
    private float _udpDeltaTime = 0.0f;

    //Animatorをpublicフィールドにするとキャラにアタッチしないでも使えるようになりそう
    private Animator _animator;


    private UdpClient _udpClient;
    private RobotMotionData _motionData;

	void Start ()
    {
        _udpClient = new UdpClient();
        _motionData = new RobotMotionData();

        //NOTE: キャラにスクリプトアタッチする前提なので適当に。
        _animator = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update ()
    {
	
        if(Enabled)
        {
            _udpDeltaTime += Time.deltaTime;
            if(_udpDeltaTime > UdpDeltaTime)
            {
                _udpDeltaTime = 0.0f;
                _motionData.CalculateAndUpdate(_animator);
                SendData(_motionData.ArrayData);
            }
        }
	}

    /// <summary>角度情報を指定されたTCPサーバーに送信します。</summary>
    private void SendData(float[] motionDataValues)
    {
        //逆三角関数の計算が事故ってないかをいちおうチェック(修正はしない)
        if (_motionData.ArrayData.Any(float.IsNaN))
        {
            Debug.Log("Warning!!! Nan Value detected");
            Debug.Log(string.Join(",", motionDataValues.Select(a => a.ToString()).ToArray()));
        }

        //Debug.Log(string.Join(",", angles.Select(a => a.ToString()).ToArray()));

        //普通に順序よくデータをパックして投げるだけ
        var sendBuffer = new byte[motionDataValues.Length * 4];
        for (int i = 0; i < motionDataValues.Length; i++)
        {
            byte[] f = BitConverter.GetBytes(motionDataValues[i]);
            Array.Copy(f, 0, sendBuffer, i * 4, 4);
        }

        _udpClient.Send(sendBuffer, sendBuffer.Length, new IPEndPoint(IPAddress.Parse(TargetIP), TargetPort));
    }

}
